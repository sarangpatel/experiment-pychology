<?php

phpinfo();
?>

