<?php
require_once('common.php');
$postData = $_POST;

$gmtsec = $postData['gmtsec'];
$user_id = $postData['user_id'];
$current_page = 'step3';


$updated_on = date('Y-m-d H:i:s');
$sql = "UPDATE users SET instruction_submit_time = '$gmtsec', current_page = '$current_page', updated_on =  '$updated_on'  WHERE id = $user_id ";
$mysqli->query($sql);
$mysqli->close();
echo json_encode(array('msg' => 'success', 'data' => array('user_id' =>  $user_id)));
exit;

?>