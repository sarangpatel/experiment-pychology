<?php
require_once('common.php');
$postData = $_POST;
$user_id = $postData['user_id'];
$data = serialize($postData);
$submitted_on = date('Y-m-d H:i:s');
$sql = "INSERT INTO experiment_data (user_id, data, submitted_on) VALUES 
	($user_id,'$data', '$submitted_on')";
$mysqli->query($sql);
$mysqli->close();
echo json_encode(array('msg' => 'success', 'data' => array('user_id' =>  $user_id)));
exit;

?>