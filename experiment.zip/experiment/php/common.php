<?php
ini_set('display_errors',0);
error_reporting(E_ALL);

header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: PUT, GET, POST, PUT, OPTIONS");
header('Access-Control-Allow-Headers: X-Requested-With, Origin, Content-Type, Access-Control-Allow-Headers,  X-Auth-Token, Cache-Control, Pragma, Authorization, Accept, Accept-Encoding');
header('Content-Type: application/json; charset=utf-8');

require_once('db.php');

function user_exists($mturk_id){
	global $mysqli;
	$sql = "SELECT id from users where mturk_id = '$mturk_id'";
	$result = $mysqli->query($sql);
	if($result->num_rows > 0 ) {
		$row = $result->fetch_assoc();
		return $row['id'];
	}else{
		return 0;
	}
}
function user_exists_by_id($user_id){
	global $mysqli;
	$sql = "SELECT id from users where id = '$user_id'";
	$result = $mysqli->query($sql);
	if($result->num_rows > 0 ) {
		$row = $result->fetch_assoc();
		return $row['id'];
	}else{
		return 0;
	}
}


function getIP(){
$ipaddress = '';
if (isset($_SERVER['REMOTE_ADDR']))
    $ipaddress = $_SERVER['REMOTE_ADDR'];
else if(isset($_SERVER['HTTP_X_FORWARDED_FOR']))
    $ipaddress = $_SERVER['HTTP_X_FORWARDED_FOR'];
else if(isset($_SERVER['HTTP_X_FORWARDED']))
    $ipaddress = $_SERVER['HTTP_X_FORWARDED'];
else if(isset($_SERVER['HTTP_FORWARDED_FOR']))
    $ipaddress = $_SERVER['HTTP_FORWARDED_FOR'];
else if(isset($_SERVER['HTTP_FORWARDED']))
    $ipaddress = $_SERVER['HTTP_FORWARDED'];
else if(isset($_SERVER['HTTP_CLIENT_IP']))
    $ipaddress = $_SERVER['HTTP_CLIENT_IP'];

return $ipaddress;

}
?>