function game(){
	var totalScore = $('#total-score').text();
	var coinsRemaining = parseInt(globalTotalCoins);
	$('#coins-remaining').text(coinsRemaining);
	$('#total-score').text(totalScore);

	//$("#textarea3").html('The next coin will be flipped in x seconds');
	//$("#textarea1").html('Your time was [y] miliseconds. Your Score ' + totalScore);

}


function initRound(){

	//if all round over
	if(globalTotalCoins <= 0){
		setCookie('completed_experiment','yes' , globalKeepLoggedIn);
		window.location.href = URL + 'thankyou.php';
		return false;
	}


	globalRoundObj = {};//reinitialize roundObj
	globalRoundObj.centerMouseTime = 0;
	globalRoundObj.coinFlipTimer = globalCoinFlippedIn; //coin will flip in X sec
	globalRoundObj.roundScore = 0;
	//$('#coin').css('cursor', 'pointer'); // 'default' to revert

	/*if($("#coin:hover").length != 0){*/
		//console.log('COIN HOVER')
		//mouseEnterInMiddleBox();
	/*}else{*/
		$("#textarea1").html('Please put your mouse in the center box');
	/*}*/



	globalRandomHeadTailOption = Math.floor(Math.random() * 2) === 0 ? 'HEAD' : 'TAIL' ;
	$('.lbox > div').html(globalRandomHeadTailOption);
	if(globalRandomHeadTailOption == 'HEAD')
	$('.rbox > div').html('TAIL');
	if(globalRandomHeadTailOption == 'TAIL')
	$('.rbox > div').html('HEAD');

	//$("#textarea3").html('The next coin will be flipped in ' + globalCoinFlippedIn + ' seconds');

}


function checkRoundTimeout(){
		
	if(typeof globalRoundObj.roundTimeoutTimer === 'undefined'){
		globalRoundObj.roundTimeoutTimer = setInterval(function(){
			var timeoutDifference = Math.round((new Date().getTime()-globalRoundObj.coinFlipResult)/1000);
			if(timeoutDifference >= globalRoundTimeout){
				alert('Timeout. Your score is 0.');
				//$("#textarea1").html('<div style ="color:#f79393">Timeout. Your Score is 0</div>');
				saveRoundData();
				globalTotalCoins -= 1;
				clearInterval(globalRoundObj.roundTimeoutTimer);
				$('#coins-remaining').text(globalTotalCoins);
				initRound();
				/*setTimeout(() => {
					$("#textarea1").html('Please put your mouse in the center box');
					initRound();
				},1600);*/
			}
		}, 1000);
	}
}

function saveRoundData(){
	var roundData = globalRoundObj;
	roundData.user_id = getCookie('user_id')
	console.log('roundData', roundData);
	//ajax post
	$.ajax({
		url:  PHPURL + 'save-experiment-data.php',
		type: "POST",
		data: roundData,
		dataType: "json",
	}).done(function (data) {
		console.log("success Round data", data);
	}).fail(function (jqXHR, exception) {
		console.log('Save Round Data Error:' + jqXHR.responseText);
	});
}

function hideScoreMsg(){
	$('#coins-remaining').text(globalTotalCoins);
	setTimeout(() => {
		$("#textarea1").html('');
		//$("#textarea1").html('Please put your mouse in the center box');
		initRound();
	},1000);
}


function flipCoin(){
	var flipResult = Math.random();
	$('#coin').removeClass();
	$("#coin div:eq(1)").addClass('side-b');
	$('#coin div:eq(0)').addClass('side-a');
	setTimeout(function(){
		if(flipResult <= 0.5){
			$('#coin').addClass('heads');
				globalCoinFlipped = 'head';
				console.log('it is head');
				globalRoundObj.coinFlipResult = new Date().getTime() + 500; //actually show flip result after 0.5 ie added 500 milisec
				checkRoundTimeout();
			}else{
				$('#coin').addClass('tails');
				globalCoinFlipped = 'tail';
				console.log('it is tails');
				globalRoundObj.coinFlipResult = new Date().getTime() + 500;
				checkRoundTimeout();
			}
	}, 100);
}

function startCoinFlippTimer(){
	console.log("coin will flip in ", globalRoundObj.coinFlipTimer);

	/*if(globalRoundObj.coinFlipTimer <= 0){
		clearInterval(globalRoundObj.coinFlippTimerId);
		return false;
		}*/

	if(typeof globalRoundObj.coinFlippTimerId === 'undefined'){
		$("#textarea3").html('The next coin will be flipped in ' + globalRoundObj.coinFlipTimer + ' seconds');
		globalRoundObj.coinFlippTimerId = setInterval(function(){
			globalRoundObj.coinFlipTimer  = globalRoundObj.coinFlipTimer - 1;
			if(globalRoundObj.coinFlipTimer == 0){
				console.log('0 reached', globalRoundObj.coinFlippTimerId);
				clearInterval(globalRoundObj.coinFlippTimerId);
				globalRoundObj.coinFlipTime = new Date().getTime();
				$("#textarea3").html('');
				flipCoin();
	
			}else{
				$("#textarea3").html('The next coin will be flipped in ' + globalRoundObj.coinFlipTimer + ' seconds');
			}
		}, 1000);
	}

}

function calculateTotalScore(){
	let score = 0;
	let answerGiven = 0;
	if(typeof globalRoundObj.answerClickTime !== 'undefined'){
		answerGiven  = Math.round(globalRoundObj.answerClickTime - globalRoundObj.coinFlipResult);
		score = globalScoreBase - answerGiven;
	}
	if(score <= 0)score = 0;
	if(typeof globalRoundObj.roundScore !== 'undefined'){
		globalRoundObj.roundScore = globalRoundObj.roundScore + score;
	}else{
		globalRoundObj.roundScore = score;
	}
	globalTotalScore += globalRoundObj.roundScore;
	$("#textarea1").html('Your time was ' + answerGiven + ' miliseconds. Your Score is ' + score);
	$('#total-score').text(globalTotalScore);

}



function mouseEnterInMiddleBox(){
	console.log('mouseenter')
	$("#textarea1").html('');
	//globalRoundObj.coinFlippTimerId = undefined;
	if(globalRoundObj.centerMouseTime === 0)
	globalRoundObj.centerMouseTime = new Date().getTime();
	startCoinFlippTimer();
}


jQuery(document).ready(function($){
	game(); //init
	initRound();
	$('.wrapper').mouseover(function(e) {

		var left = e.pageX - $(this).offset().left;
		var top = e.pageY - $(this).offset().top;
		console.log('mouse movements', left + 'x' + top)
	});

	$('#coin').mouseenter(function(e) {
		mouseEnterInMiddleBox();
	});

	$('#coin').mouseleave(function(e) {
		/*if(globalRoundObj.coinFlipTimer > 0){
			$("#textarea1").html('Please put your mouse in the center box');
			$("#textarea3").html('');

			let coinFlippTimerId = globalRoundObj.coinFlippTimerId || null;
			if(coinFlippTimerId !== null)
			clearInterval(coinFlippTimerId);
			initRound();
		}*/
		console.log('flipresut',globalRoundObj.coinFlipResult)
			if(!globalRoundObj.coinFlipResult){
				$("#textarea1").html('Please put your mouse in the center box');
				$("#textarea3").html('');
				let coinFlippTimerId = globalRoundObj.coinFlippTimerId || null;
				if(coinFlippTimerId !== null)
				clearInterval(coinFlippTimerId);
				initRound();
			}


	});




	$( ".rbox, .lbox" ).mouseenter(function(e) {
		var left = e.pageX - $(this).offset().left;
		var top = e.pageY - $(this).offset().top;
		console.log('mouseenter', left, top)
		globalRoundObj.answerCursorEnterTime = new Date().getTime();
		//var optionSelected = $(this).find('div').text();
		//if(optionSelected.toLowerCase() == globalCoinFlipped.toLowerCase()){
			//globalRoundObj.answerCursorEnterTime = new Date().getTime();
		//}
	});


	$('.rbox, .lbox').click(function(e) {
		console.log('going', globalRoundObj.coinFlipResult);
		if(typeof globalRoundObj.coinFlipResult !== 'undefined'){ 
			console.log('result')
			var optionSelected = $(this).find('div').text();
			var left = e.pageX - $(this).offset().left ;
			var top = e.pageY - $(this).offset().top;
			if(optionSelected.toLowerCase() == globalCoinFlipped.toLowerCase()){
				console.log('CORRECT ANSWER' , left + 'x' + top);
				if(typeof globalRoundObj.roundTimeoutTimer !== 'undefined')
				clearInterval(globalRoundObj.roundTimeoutTimer);
				globalRoundObj.answerClickTime = new Date().getTime();
				globalRoundObj.correctAnswer = "yes";

				calculateTotalScore();
				saveRoundData();
				globalTotalCoins -= 1;

				hideScoreMsg(); //save round data in backend

			}else{
				console.log('Wrong aNSWER');
				globalRoundObj.answerClickTime = new Date().getTime();
				globalRoundObj.correctAnswer = "no";
				globalRoundObj.roundScore = 0; 

				if(typeof globalRoundObj.roundTimeoutTimer !== 'undefined')
				clearInterval(globalRoundObj.roundTimeoutTimer);
				$("#textarea1").html('Wrong answer given. Your Score is 0');
				saveRoundData();
				globalTotalCoins -= 1;

				hideScoreMsg(); //save round data in backend
			}

		}
	});



	/*$( ".lbox" ).mousemove(function(e) {
		var left = e.pageX - $(this).offset().left ;
		var top = e.pageY - $(this).offset().top;
		console.log('mouseover', left, top)

	});

	$( ".lbox" ).mouseleave(function(e) {
		var left = e.pageX - $(this).offset().left ;
		var top = e.pageY - $(this).offset().top;
		console.log('mouseleave', left, top)

	});*/

})// jqueryReadu


