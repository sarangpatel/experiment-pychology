//GLOBAL variables
var URL  = "http://localhost/experiment/";
var PHPURL  = "http://localhost/experiment/php/";


//var URL  = "https://novaproduct.net/experiment/";
//var PHPURL  = URL + "php/";

var globalKeepLoggedIn = (60 * 60 * 24) * 30; //30 days
var widthLimit = 1000;
var globalDefaultText = "??''";
var globalGridCM = 20; //in cm
var globalNumberOfGrids = 3
var globalBoxRatio = globalGridCM/6; //in cm ( gridlength / box ration)
var globalCommonPixelPerCM = 45 //pixels in CM

//game setting
var globalTotalCoins = 15;
var globalRandomHeadTailOption;
var globalCoinFlipped = '';
var globalRoundObj = {};
var globalCoinFlippedIn = 3; //3 sec
var globalRoundTimeout = 3; //3 sec
var globalScoreBase = 2000; //2000 milisec ie 2 sec
var globalTotalScore = 0; //2000 milisec ie 2 sec


//measurements used for calibration
var cardcm = 8.6; //cm, width of credit card
var cardinch = 3.4; //inches, width of credit card
var distance = 50; //cm, chosen distance from screen as this approximates to an arm's length
var pxDiagonal = Math.sqrt(Math.pow(screen.width,2) + Math.pow(screen.height,2)); //get the screen's diagonal size in pixels

//set up the calibratio object images
var cardimg = new Image();
var imgDir = URL + "img/"; //the directory where the object images are stored
cardimg.src = imgDir + "card.png"; //location and name of the credit card image file

//setting up initial values
var cardRatio = 0; //this will store the card's ratio of width to height
var screenMin = 10; //minimum screen size allowed for the task
var screenMax = 55; //earlier 40, maximum screen size allowed for the task

//slider parameters for changing the displayed object's size
//the units are inches * 10 (the * 10 helps to elongate the slider's appearances)
var sliderMin = screenMin * 10;
var sliderMax = screenMax * 10;

//once the card image is done loading, calculate the card ratio
cardimg.onload = setCardRatio;

//calculate the width to height ratio of the credit card image
function setCardRatio() {
	cardRatio = this.width/this.height;
	drawContent();

}

//get the current value of the slider
function getSliderValue() {
	return sliderMax - $("#slider").slider("value") + sliderMin;
}




$(document).ready(init);

/*** START: calibration **/
function calibration(){
	//set the starting value for the pixel per inch parameter
	$("#slider").slider({
		min: sliderMin,
		max: sliderMax,
		value: 250,
		slide: updateNumbers,
		stop: updateNumbers
	});
	$('#diagsize').text(globalDefaultText);

	window.pxperinch = pxDiagonal/(getSliderValue()/10);

	drawContent();

}


// This is the callback function for the slider. As the slider moves, the output values
// on the screen are updated.
function updateNumbers() {
	//an object needs to be selected in order to use the slider (since the slider is meant
	//for adjusting a calibration object's size); if no object is selected, but the subject tries
	//to move the slider, a warning dialog box pops up
	var inches = getSliderValue()/10; //convert the slider value to inches
	window.pxperinch = pxDiagonal/inches; //calculate pixels per inch
	$("#diagsize").text(inches.toFixed(1) + "\""); //update screen size output
	drawObject(); //update the image size of the calibration object
}

//This function sets up the HTML5 canvas
function drawContent() {
	//grab the canvas object and set it up for drawing
	var canvas=document.getElementById("myCanvas");
	var c=canvas.getContext("2d");

	//set the size of the canvas
	canvas.width = 600;
	canvas.height = 600;

	//set the background to be gray
	c.fillStyle="rgb(128, 128, 128)";
	c.fillRect(0,0,canvas.width,canvas.height);
	drawObject();
}

// This function updates the appearance of the calibration object in step 1
function drawObject() {
	//get the HTML% canvas and determine its center coordinates
	var canvas=document.getElementById("myCanvas");
	var c=canvas.getContext("2d");
	var centerX = canvas.width/2;
	var centerY = canvas.height/2;

	//clear the canvas and set a gray background
	c.fillStyle="rgb(128, 128, 128)";
	c.fillRect(0,0,canvas.width,canvas.height);
	
	//if the selected image is a credit card, then update the card size based on the calculated
	//pixels per inch, and then redraw the card to display to the subject 
	var cardWidth = Math.round(window.pxperinch*cardinch);
	var cardHeight = Math.round(cardWidth/cardRatio);
	c.drawImage(cardimg, 0, 10, cardWidth, cardHeight);
}


// This function calculates pixels per degrees, based on the size of the monitor
function getConversion() {
	//first pixels per inch is converted to pixels per centimeter (used for drawing the brightness/contrast grayscale rectangles)
	window.pxpercm = Math.round(window.pxperinch/2.54);
	window.monitorSize = $("#diagsize").text();
	console.log(window.monitorSize);
	$('#calibrateFrm').find('input[name="screen_size"]').val(window.monitorSize);
	$('#calibrateFrm').find('input[name="pxpercm"]').val(window.pxpercm);
	$('#calibrateFrm').find('input[name="gmtsec"]').val(getTime());
	$('#calibrateFrm').find('input[name="user_id"]').val(getCookie('user_id'));

	//then calculate pixels per degree
	//var angle = Math.atan(screen.height/screen.width);
	//var diagCM = (getSliderValue()/10)*2.54; //inch to cm
	
	//var screenWidthCM = diagCM * Math.cos(angle);
	//window.pxperdeg = Math.PI/180 * screen.width * distance/screenWidthCM;

	//also get the final confirmed monitor size
	//window.monitorSize = parseFloat($("#screenInput").val());
}



/*** END: calibratoin **/

//this function initializes all of the button callbacks
function init() {

	if($(window).width() <= widthLimit) {
		$("body").css("width", widthLimit + "px");
	}
	else {
		$("body").css("width","100%");
	}

	if(mobileAndTabletCheck()){
		alert('You must be on a computer to complete this task”');
		window.location.href = PHPURL + '404.php';
		return false;
	}


	if(getCookie('completed_experiment') != '' && getCookie('completed_experiment') == 'yes' ){
		alert('You already completed experiment.')
		window.location.href = URL + 'thankyou.php';
	}


	if(getCookie('current_page') == ''){
		setCookie('current_page','step1' , globalKeepLoggedIn);
	}


	if(getCookie('pxpercm') != ''){
		setMeasurement(getCookie('pxpercm'));
	}

	
	calibration();



	$('#step1').hide();
	$('#step2').hide();
	$('#step3').hide();
	$('#step4').hide();
	$('#step5').hide();

	$('#' + getCookie('current_page')).show();

	$("#mturkFrmSubmitButton").button();
	$("#instructionFrmSubmitButton" ).button();
	$("#questionFrmSubmitButton" ).button();
	$("#calibrateFrmSubmitButton" ).button();




	$.validator.addMethod("emptyField", function(value, element) {
		if($.trim($(element).val()) == '')
			return false;
		else
			return true;
	}/*, "Please enter valid MTurk ID"*/);

	$.validator.addMethod("checkAnswer", function(value, elem, param) {
		//console.log($(elem).attr('name'), '===',value);
		console.log($('input[name="' + $(elem).attr('name') + '"]:checked').length);
		return $('input[name="' + $(elem).attr('name') + '"]:checked').length > 0 ? true : false;
	},"You must select at least one Answer");



	$("#mturkFrm").validate({
		rules:{
			mturk_id:{
				emptyField: true
			}
		},
		errorElement : 'div',
		errorLabelContainer: '.errorTxt',

		messages: {
			mturk_id:{
				emptyField: "Please enter valid MTurk ID"
			},
		},

		submitHandler: function(form){
			let gmtsec = getTime(); //get the user's time in sec ( GMT )
			$(form).find("input[name='gmtsec']").val(gmtsec); 
			$(form).find("input[name='browser']").val(navigator.userAgent);

			var resolution = screen.width + 'x' + screen.height;
			$(form).find("input[name='resolution']").val(resolution);
			$("#mturkFrmSubmitButton" ).button( "option", "label", "Please wait..." );
			$( "#mturkFrmSubmitButton" ).button({
			  disabled: true
			});
			$.ajax({
				url:  PHPURL + 'mturk.php',
				type: "POST",
				data: $(form).serialize(),
				dataType: "json",
				}).done(function (data) {
					setCookie('user_id', data.data.user_id, globalKeepLoggedIn);
					setCookie('current_page','step2' , globalKeepLoggedIn);
					$('#step1').hide();
					$('#step2').show();
					//JSON.parse(getCookie('loggedUser')).appUserId
					$( "#mturkFrmSubmitButton" ).button({
					  disabled: false
					});
					$("#mturkFrmSubmitButton" ).button( "option", "label", "Submit" );
					console.log(data);
				}).fail(function (jqXHR, exception) {
					alert('Error:' + jqXHR.responseText);
					$( "#mturkFrmSubmitButton" ).button({
					  disabled: false
					});
					$("#mturkFrmSubmitButton" ).button( "option", "label", "Submit" );
				});
		}
	});


	$("#instructionFrm").validate({
		submitHandler: function(form){
			let gmtsec = getTime(); //get the user's time in sec ( GMT )
			$(form).find("input[name='gmtsec']").val(gmtsec); 
			$("#instructionFrmSubmitButton" ).button( "option", "label", "Please wait..." );
			$( "#instructionFrmSubmitButton" ).button({
			  disabled: true
			});
			$.ajax({
				url:  PHPURL + 'instruction.php',
				type: "POST",
				data: {gmtsec: gmtsec, user_id: getCookie('user_id')},
				dataType: "json",
				}).done(function (data) {
					setCookie('current_page','step3' , globalKeepLoggedIn);
					$('#step1').hide();
					$('#step2').hide();
					$('#step3').show();
					$( "#instructionFrmSubmitButton" ).button({
					  disabled: false
					});
					$("#instructionFrmSubmitButton" ).button( "option", "label", "Continue" );
					console.log(data);
				}).fail(function (jqXHR, exception) {
					alert('Error:' + jqXHR.responseText);
					$( "#instructionFrmSubmitButton" ).button({
					  disabled: false
					});
					$("#instructionFrmSubmitButton" ).button( "option", "label", "Continue" );
				});
		}
	});


	$("#questionFrm").validate({
		rules:{
			"answer[1][]":{
				checkAnswer: true
			},
			"answer[2][]":{
				checkAnswer: true
			},
			"answer[3][]":{
				checkAnswer: true
			}
		},
		messages: {
			"answer[1][]":{
				checkAnswer: "You must select atleast 1 Answer"
			},
			"answer[2][]":{
				checkAnswer: "You must select atleast 1 Answer"
			},
			"answer[3][]":{
				checkAnswer: "You must select atleast 1 Answer"
			}

		},

		errorPlacement: function (error, element) {
            if (element.attr("type") == "radio") {
                error.insertAfter($(element).parent().parent());
            } else {
                // something else
            }
        },

		submitHandler: function(form){
			let gmtsec = getTime(); //get the user's time in sec ( GMT )
			$(form).find("input[name='gmtsec']").val(gmtsec); 
			console.log('cookie', getCookie('user_id'));
			$(form).find("input[name='user_id']").val(getCookie('user_id')); 
			console.log("formsubmitted");

			$("#questionFrmSubmitButton" ).button( "option", "label", "Please wait..." );
			$( "#questionFrmSubmitButton" ).button({
			  disabled: true
			});
			$.ajax({
				url:  PHPURL + 'test.php',
				type: "POST",
				data: $(form).serialize(),
				dataType: "json",
				}).done(function (data) {
					$( "#questionFrmSubmitButton" ).button({
					  disabled: false
					});
					$("#questionFrmSubmitButton" ).button( "option", "label", "Submit" );
					if(data.length > 0){ /*** answer are wrong ****/
						alert('Please correct answer and submit again.');
						$("#questionFrm").trigger("reset");

						let body = $("body");
						let top = body.scrollTop() // Get position of the body
						if(top!=0)
						body.animate({scrollTop:0}, '500');
						$(window).scrollTop(0);

						//setCookie('current_page','step2' , globalKeepLoggedIn);
						//$('#step1').hide();
						$//('#step3').hide();
						$//('#step2').show();

					}else{
						submitTest(gmtsec);
					}
					console.log("length",data.length)
					console.log(data);
				}).fail(function (jqXHR, exception) {
					console.log('Error:' + jqXHR.responseText);
					//alert('Error:' + jqXHR.responseText);
					$( "#questionFrmSubmitButton" ).button({
					  disabled: false
					});
					$("#questionFrmSubmitButton" ).button( "option", "label", "Submit" );
				});
		}
	});

	$("#calibrateFrm").validate({
		submitHandler: function(form){
			if($('#diagsize').text() ==  globalDefaultText){
				alert('Please calibrate first.');
				return false;
			}else{
				$("#calibrateFrmSubmitButton" ).button( "option", "label", "Please wait..." );
				$( "#calibrateFrmSubmitButton" ).button({
				  disabled: true
				});

				getConversion();

				$.ajax({
					url:  PHPURL + 'add-calibration.php',
					type: "POST",
					data: $(form).serialize(),
					dataType: "json",
					}).done(function (data) {
						setCookie('current_page','step5' , globalKeepLoggedIn);
						var pxpercm = $('#calibrateFrm').find('input[name="pxpercm"]').val();
						setMeasurement(pxpercm);


						$('#step1').hide();
						$('#step2').hide();
						$('#step3').hide();
						$('#step4').hide();
						$('#step5').show();
						$( "#calibrateFrmSubmitButton" ).button({
						  disabled: false
						});
						$("#calibrateFrmSubmitButton" ).button( "option", "label", "Submit" );
						console.log(data);
					}).fail(function (jqXHR, exception) {
						alert('Error:' + jqXHR.responseText);
						$( "#calibrateFrmSubmitButton" ).button({
						  disabled: false
						});
						$("#calibrateFrmSubmitButton" ).button( "option", "label", "Submit" );
					});
			}
		}
	});

}//init



// this function gets the GMT time ( in seconds ) from local time of the subject
function getTime() {
	const now = new Date()  
	const utcMilllisecondsSinceEpoch = now.getTime() + (now.getTimezoneOffset() * 60 * 1000);  
	const utcSecondsSinceEpoch = Math.round(utcMilllisecondsSinceEpoch / 1000) 
	return utcSecondsSinceEpoch;
}

function submitTest(gmtsec){
	$.ajax({
		url:  PHPURL + 'submit-test.php',
		type: "POST",
		data: {gmtsec: gmtsec, user_id : getCookie('user_id')},
		dataType: "json",
	}).done(function (data) {
		console.log('submit test time',data);
		setCookie('current_page','step4' , globalKeepLoggedIn);
		$('#step1').hide();
		$('#step2').hide();
		$('#step3').hide();
		$('#step4').show();
	}).fail(function (jqXHR, exception) {
		console.log('ERROR Submit Test Time:' + jqXHR.responseText);
		alert('Error:' + jqXHR.responseText);
	});
}

function setMeasurement(pxpercm){
	setCookie('pxpercm', pxpercm, globalKeepLoggedIn); //submitted by user

	var pxpercm = parseFloat(pxpercm) + (parseFloat(globalCommonPixelPerCM) - parseFloat(pxpercm)); //making pxpercm common for al resolutions
	console.log('after calculation pxpercm', pxpercm);
	var width = Math.floor(pxpercm * globalGridCM); //30cm to px
	var box = Math.floor(pxpercm * globalBoxRatio); //5cm to px
	var columns = globalGridCM / globalNumberOfGrids; //colums in cm

	console.log( "Mesurement:===",  "box:" + box + ", main:" + width + ", perpercm:" + pxpercm);
	 $( '.page-container' ).css( "width", width + 'px' );
	 $( '.main' ).css( "width", width + 'px' );
	 $( '.content' ).css( "width", width + 'px' );



	 var gridcolumn = Math.floor(pxpercm * columns);
	 $( '.wrapper' ).css( "grid-template-columns", `${gridcolumn}px ${gridcolumn}px  ${gridcolumn}px `);
	 $( '.textmain' ).css( "width", width + 'px' );
	 $( '.text1, .text2, .text3' ).css( "grid-template-columns", `${width}px`);


	 $( '.lbox' ).css({"width": box + 'px' ,"height": box + 'px' });
	 $( '.rbox' ).css({"width": box + 'px',"height": box + 'px'});
	 $( '#coin' ).css({"width": box + 'px',"height": box + 'px'});

	 //${box}px ${box}px
 	 $( '.side-a' ).css({"width": `${box}px`, height:  `${box}px`  });
	 $( '.side-b' ).css({"width": `${box}px`, height:  `${box}px`  });
	 $( '.side-nuetral' ).css({"width": `${box}px`, height:  `${box}px`  });

	 /*$( '.side-a' ).css({"background-size": `"${box}px ${box}px"`  });
	 $( '.side-b' ).css({"background-size": `"${box}px ${box}px"` });
	 $( '.side-nuetral' ).css({"background-size": `"${box}px ${box}px"	` });*/
}

//returns true if mobile / tablet device
function mobileAndTabletCheck() {
	let check = false;
	(function(a){if(/(android|bb\d+|meego).+mobile|avantgo|bada\/|blackberry|blazer|compal|elaine|fennec|hiptop|iemobile|ip(hone|od)|iris|kindle|lge |maemo|midp|mmp|mobile.+firefox|netfront|opera m(ob|in)i|palm( os)?|phone|p(ixi|re)\/|plucker|pocket|psp|series(4|6)0|symbian|treo|up\.(browser|link)|vodafone|wap|windows ce|xda|xiino|android|ipad|playbook|silk/i.test(a)||/1207|6310|6590|3gso|4thp|50[1-6]i|770s|802s|a wa|abac|ac(er|oo|s\-)|ai(ko|rn)|al(av|ca|co)|amoi|an(ex|ny|yw)|aptu|ar(ch|go)|as(te|us)|attw|au(di|\-m|r |s )|avan|be(ck|ll|nq)|bi(lb|rd)|bl(ac|az)|br(e|v)w|bumb|bw\-(n|u)|c55\/|capi|ccwa|cdm\-|cell|chtm|cldc|cmd\-|co(mp|nd)|craw|da(it|ll|ng)|dbte|dc\-s|devi|dica|dmob|do(c|p)o|ds(12|\-d)|el(49|ai)|em(l2|ul)|er(ic|k0)|esl8|ez([4-7]0|os|wa|ze)|fetc|fly(\-|_)|g1 u|g560|gene|gf\-5|g\-mo|go(\.w|od)|gr(ad|un)|haie|hcit|hd\-(m|p|t)|hei\-|hi(pt|ta)|hp( i|ip)|hs\-c|ht(c(\-| |_|a|g|p|s|t)|tp)|hu(aw|tc)|i\-(20|go|ma)|i230|iac( |\-|\/)|ibro|idea|ig01|ikom|im1k|inno|ipaq|iris|ja(t|v)a|jbro|jemu|jigs|kddi|keji|kgt( |\/)|klon|kpt |kwc\-|kyo(c|k)|le(no|xi)|lg( g|\/(k|l|u)|50|54|\-[a-w])|libw|lynx|m1\-w|m3ga|m50\/|ma(te|ui|xo)|mc(01|21|ca)|m\-cr|me(rc|ri)|mi(o8|oa|ts)|mmef|mo(01|02|bi|de|do|t(\-| |o|v)|zz)|mt(50|p1|v )|mwbp|mywa|n10[0-2]|n20[2-3]|n30(0|2)|n50(0|2|5)|n7(0(0|1)|10)|ne((c|m)\-|on|tf|wf|wg|wt)|nok(6|i)|nzph|o2im|op(ti|wv)|oran|owg1|p800|pan(a|d|t)|pdxg|pg(13|\-([1-8]|c))|phil|pire|pl(ay|uc)|pn\-2|po(ck|rt|se)|prox|psio|pt\-g|qa\-a|qc(07|12|21|32|60|\-[2-7]|i\-)|qtek|r380|r600|raks|rim9|ro(ve|zo)|s55\/|sa(ge|ma|mm|ms|ny|va)|sc(01|h\-|oo|p\-)|sdk\/|se(c(\-|0|1)|47|mc|nd|ri)|sgh\-|shar|sie(\-|m)|sk\-0|sl(45|id)|sm(al|ar|b3|it|t5)|so(ft|ny)|sp(01|h\-|v\-|v )|sy(01|mb)|t2(18|50)|t6(00|10|18)|ta(gt|lk)|tcl\-|tdg\-|tel(i|m)|tim\-|t\-mo|to(pl|sh)|ts(70|m\-|m3|m5)|tx\-9|up(\.b|g1|si)|utst|v400|v750|veri|vi(rg|te)|vk(40|5[0-3]|\-v)|vm40|voda|vulc|vx(52|53|60|61|70|80|81|83|85|98)|w3c(\-| )|webc|whit|wi(g |nc|nw)|wmlb|wonu|x700|yas\-|your|zeto|zte\-/i.test(a.substr(0,4))) check = true;})(navigator.userAgent||navigator.vendor||window.opera);
	return check;
};

function detectTrackPad(e) {
	var isTouchPad = e.wheelDeltaY ? e.wheelDeltaY === -3 * e.deltaY : e.deltaMode === 0
	var mousetype = isTouchPad ? "touchpad" : "mouse";
	console.log("ss", mousetype);
	$('#mturkFrm').find("input[name='browser']").val(mousetype);
}

document.addEventListener("mousewheel", detectTrackPad, false);
document.addEventListener("DOMMouseScroll", detectTrackPad, false);

