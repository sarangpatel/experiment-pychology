<!DOCTYPE html>
<html>
	<head>
		<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
		<title>Psychological Experiment - Thank You</title>
	</head>
	<body>
			<img src = "./img/thankyou.jpg" style="width:100%">
	</body>
</html>