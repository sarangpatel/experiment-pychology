CREATE TABLE `log_of_wrong_answers` (
  `id` int NOT NULL AUTO_INCREMENT PRIMARY KEY,
  `user_id` int NOT NULL,
  `wrong_answers` varchar(100) NOT NULL,
  `submitted_on` datetime NOT NULL
) ENGINE='InnoDB' COLLATE 'utf8mb4_general_ci';

ALTER TABLE `log_of_wrong_answers`
CHANGE `submitted_on` `submitted_on` int NOT NULL AFTER `wrong_answers`;